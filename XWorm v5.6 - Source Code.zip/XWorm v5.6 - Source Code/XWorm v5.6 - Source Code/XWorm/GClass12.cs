namespace XWorm;

public class GClass12
{
	public string type { get; set; }
}


//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower


