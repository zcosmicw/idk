using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace XWorm;

[CompilerGenerated]
[DebuggerDisplay("<generated method>", Type = "<generated method>")]
internal delegate T Delegate1<T>();


//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower


