namespace XWorm;

public class GClass18 : GClass12
{
	public string sUrl { get; set; }

	public string sTitle { get; set; }

	public int iCount { get; set; }
}


//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower


