namespace XWorm;

public class GClass17 : GClass12
{
	public string sUrl { get; set; }

	public string sUsername { get; set; }

	public string sPassword { get; set; }

	public string Target { get; set; }
}


//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower


